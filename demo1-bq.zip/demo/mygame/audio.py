jump = Audio('assets/assets_jump.mp3', loop=False, autoplay=False)

walk = Audio('assets/assets_walk.mp3', loop=False, autoplay=False, volume=0.7)

punchy = Audio('assets/punchy.mp3', loop=False, autoplay=False)

magicWand = Audio('assets/magicWand.mp3', loop=False, autoplay=False)
