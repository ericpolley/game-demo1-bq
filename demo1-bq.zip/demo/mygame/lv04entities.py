

step3 = Entity(model='cube', color=color.brown, texture='brick', text_scale=(3, 3), scale=(
    6, 3, 6), collider='box', position=(25, 1.4, 85))

step4 = Entity(model='cube', color=color.brown, texture='brick', text_scale=(3, 3), scale=(
    6, 3, 6), collider='box', position=(25, 1.8, 75))

step5 = Entity(model='cube', color=color.brown, texture='brick', text_scale=(3, 3), scale=(
    6, 3, 6), collider='box', position=(25, 2.2, 65))


checkPoint03 = Entity(model='sphere', color=color.green, scale=(
    1, 1, 1), collider='box', position=(25, 6.1, 65))
checkPoint03stand = Entity(model='cube', color=color.gray, scale=(
    6, .25, 6), collider='box', position=(25, 3.875, 65))
