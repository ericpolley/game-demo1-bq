"""
This package contains only the :class:`.MotionTrail` class.
"""
