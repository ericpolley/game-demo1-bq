"""
This package provides the Python interface to functionality relating to
the Panda3D Runtime environment.

.. deprecated:: 1.10.0
   The p3d packaging system has been replaced with the new setuptools-based
   system.  See the :ref:`distribution` manual section.
"""
