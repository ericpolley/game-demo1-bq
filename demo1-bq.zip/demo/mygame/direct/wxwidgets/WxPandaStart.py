from .WxPandaShell import *
base.app = WxPandaShell()

