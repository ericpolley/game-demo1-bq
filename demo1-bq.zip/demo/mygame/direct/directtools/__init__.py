"""
This package contains the DIRECT tools, a set of tkinter tools for exploring
and manipulating the Panda3D scene graph.  By default, these are disabled,
but they can be explicitly enabled using the following PRC configuration::

   want-directtools true
   want-tk true
"""
